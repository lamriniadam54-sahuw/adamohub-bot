export type SetupIds = {
  categories: Record<string, string>;
  channels: Record<string, string>;
  roles: Record<string, string>;
};

export type TicketType = "support" | "payment";
export type TicketPriority = "low" | "normal" | "high";