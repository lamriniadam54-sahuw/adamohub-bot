import {
  ActionRowBuilder,
  AttachmentBuilder,
  AuditLogEvent,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  Client,
  Collection,
  EmbedBuilder,
  GatewayIntentBits,
  GuildMember,
  PermissionFlagsBits,
  REST,
  Routes,
  SlashCommandBuilder,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  type ButtonInteraction,
  type ChatInputCommandInteraction,
  type Guild,
  type Message,
  type TextChannel,
  type User,
} from "discord.js";
import { logger } from "../lib/logger";
import {
  addWarning,
  createGiveaway,
  createTicket,
  finishGiveaway,
  getActiveGiveaways,
  getOpenTicketCount,
  getSetup,
  getTicket,
  listStaleTickets,
  listWarnings,
  removeWarning,
  ticketIsOpen,
  updateTicket,
} from "./db";
import {
  CHANNEL_KEYS,
  COLORS,
  NOTIFICATION_ROLES,
  ROLE_DEFINITIONS,
  ROLE_NAMES,
  STAFF_ROLES,
  roleKeyFromName,
} from "./constants";
import { getRole, getTextChannel, setupGuild } from "./setup";
import { sendTranscript } from "./transcript";
import type { TicketPriority, TicketType } from "./types";

const token = process.env.DISCORD_BOT_TOKEN;
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.GuildModeration,
  ],
});

const duplicateMessages = new Map<string, number[]>();
const commandBuilders = [
  new SlashCommandBuilder()
    .setName("setup")
    .setDescription("Create the Adamohub categories, channels, roles, and panels.")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  new SlashCommandBuilder()
    .setName("test")
    .setDescription("Send a preview of the welcome message.")
    .addSubcommand((subcommand) =>
      subcommand.setName("welcome").setDescription("Preview the Adamohub welcome message."),
    ),
  new SlashCommandBuilder().setName("status").setDescription("Show the current Adamohub status."),
  new SlashCommandBuilder()
    .setName("setstatus")
    .setDescription("Publish a new status message.")
    .addStringOption((option) => option.setName("message").setDescription("The status to publish.").setRequired(true)),
  new SlashCommandBuilder()
    .setName("changelog")
    .setDescription("Publish a changelog entry.")
    .addStringOption((option) => option.setName("message").setDescription("The change to publish.").setRequired(true)),
  new SlashCommandBuilder()
    .setName("userinfo")
    .setDescription("Show member details, warnings, verification, and ticket stats.")
    .addUserOption((option) => option.setName("user").setDescription("The member to inspect.")),
  new SlashCommandBuilder()
    .setName("warn")
    .setDescription("Warn a member and apply the configured escalation.")
    .addUserOption((option) => option.setName("user").setDescription("Member to warn.").setRequired(true))
    .addStringOption((option) => option.setName("reason").setDescription("Reason for the warning.").setRequired(true)),
  new SlashCommandBuilder()
    .setName("warnings")
    .setDescription("List a member's warnings.")
    .addUserOption((option) => option.setName("user").setDescription("Member to inspect.").setRequired(true)),
  new SlashCommandBuilder()
    .setName("removewarn")
    .setDescription("Remove one warning from a member.")
    .addUserOption((option) => option.setName("user").setDescription("Member whose warning should be removed.").setRequired(true))
    .addIntegerOption((option) =>
      option.setName("warning").setDescription("Warning number to remove.").setMinValue(1).setRequired(true),
    )
    .addStringOption((option) => option.setName("reason").setDescription("Reason for removing the warning.")),
  new SlashCommandBuilder()
    .setName("kick")
    .setDescription("Kick a member.")
    .addUserOption((option) => option.setName("user").setDescription("Member to kick.").setRequired(true))
    .addStringOption((option) => option.setName("reason").setDescription("Reason for the kick.").setRequired(true)),
  new SlashCommandBuilder()
    .setName("ban")
    .setDescription("Ban a member.")
    .addUserOption((option) => option.setName("user").setDescription("Member to ban.").setRequired(true))
    .addStringOption((option) => option.setName("reason").setDescription("Reason for the ban.").setRequired(true)),
  new SlashCommandBuilder()
    .setName("timeout")
    .setDescription("Timeout a member.")
    .addUserOption((option) => option.setName("user").setDescription("Member to timeout.").setRequired(true))
    .addIntegerOption((option) =>
      option.setName("minutes").setDescription("Timeout length in minutes.").setMinValue(1).setMaxValue(40320).setRequired(true),
    )
    .addStringOption((option) => option.setName("reason").setDescription("Reason for the timeout.").setRequired(true)),
  new SlashCommandBuilder()
    .setName("clear")
    .setDescription("Delete recent messages.")
    .addIntegerOption((option) =>
      option.setName("amount").setDescription("Number of messages, from 1 to 100.").setMinValue(1).setMaxValue(100).setRequired(true),
    ),
  new SlashCommandBuilder()
    .setName("create")
    .setDescription("Create community content.")
    .addSubcommand((subcommand) =>
      subcommand
        .setName("giveaway")
        .setDescription("Start a giveaway.")
        .addStringOption((option) => option.setName("prize").setDescription("Giveaway prize.").setRequired(true))
        .addIntegerOption((option) => option.setName("minutes").setDescription("Duration in minutes.").setMinValue(1).setMaxValue(10080).setRequired(true))
        .addIntegerOption((option) => option.setName("winners").setDescription("Number of winners.").setMinValue(1).setMaxValue(20).setRequired(true)),
    ),
  new SlashCommandBuilder()
    .setName("verification")
    .setDescription("Publish the verification panel."),
  new SlashCommandBuilder().setName("ticket").setDescription("Publish the support and payment ticket panel."),
  new SlashCommandBuilder().setName("reactionroles").setDescription("Publish the notification role panel."),
  new SlashCommandBuilder().setName("close").setDescription("Close the current ticket."),
  new SlashCommandBuilder().setName("reopen").setDescription("Reopen the current ticket."),
  new SlashCommandBuilder().setName("claim").setDescription("Claim the current ticket."),
  new SlashCommandBuilder()
    .setName("priority")
    .setDescription("Set current ticket priority.")
    .addStringOption((option) =>
      option
        .setName("level")
        .setDescription("Ticket priority.")
        .setRequired(true)
        .addChoices(
          { name: "Low", value: "low" },
          { name: "Normal", value: "normal" },
          { name: "High", value: "high" },
        ),
    ),
] as const;

const commands = commandBuilders.map((command) => command.toJSON());

function isStaffMember(member: GuildMember | null) {
  return Boolean(
    member &&
      (member.permissions.has(PermissionFlagsBits.ManageGuild) ||
        member.roles.cache.some((role) =>
          STAFF_ROLES.includes(roleKeyFromName(role.name) as (typeof STAFF_ROLES)[number]),
        )),
  );
}

function isBotOperator(member: GuildMember | null, guild: Guild) {
  return Boolean(
    member &&
      (member.id === guild.ownerId ||
        member.roles.cache.some(
          (role) => role.name === ROLE_DEFINITIONS.Owner || role.name === ROLE_DEFINITIONS.Developer,
        )),
  );
}

async function logStaff(guild: Guild, text: string, color: number = COLORS.blue) {
  const setup = await getSetup(guild.id);
  const channel = getTextChannel(guild, setup?.channelIds?.[CHANNEL_KEYS.staffLogs]);
  if (!channel) return;
  await channel.send({
    embeds: [new EmbedBuilder().setTitle("Staff log").setDescription(text).setColor(color).setTimestamp()],
  });
}

function welcomeBanner() {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="360" viewBox="0 0 1200 360">
    <defs><linearGradient id="g" x1="0" x2="1"><stop stop-color="#111126"/><stop offset="1" stop-color="#48258f"/></linearGradient></defs>
    <rect width="1200" height="360" rx="28" fill="url(#g)"/>
    <circle cx="1010" cy="40" r="230" fill="#8b5cf6" opacity=".18"/>
    <circle cx="1080" cy="330" r="170" fill="#22c55e" opacity=".12"/>
    <text x="72" y="150" fill="white" font-size="64" font-family="Arial, sans-serif" font-weight="700">ADAMOHUB</text>
    <text x="76" y="216" fill="#ddd6fe" font-size="30" font-family="Arial, sans-serif">Welcome to the community.</text>
  </svg>`;
  return new AttachmentBuilder(Buffer.from(svg), { name: "adamohub-banner.svg" });
}

function welcomeEmbed(member: GuildMember) {
  return new EmbedBuilder()
    .setColor(COLORS.purple)
    .setTitle(`Welcome in Adamohub, ${member.user.username}!`)
    .setDescription("We are glad to have you here. Start with the rules and verification, then join the conversation.")
    .setImage("attachment://adamohub-banner.svg")
    .setTimestamp();
}

async function sendWelcome(channel: TextChannel, member: GuildMember) {
  await channel.send({ content: `Welcome in Adamohub, ${member}!`, embeds: [welcomeEmbed(member)], files: [welcomeBanner()] });
}

async function publishVerification(guild: Guild, channel: TextChannel) {
  if (await channelHasPanel(channel, "Verification", "verify")) return;
  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("verify").setLabel("Verify me").setStyle(ButtonStyle.Success),
  );
  await channel.send({
    embeds: [
      new EmbedBuilder()
        .setColor(COLORS.success)
        .setTitle("Verification")
        .setDescription("Click the **Verify me** button below. The bot will give you the Verified role and unlock the member channels.")
        .setFooter({ text: guild.name }),
    ],
    components: [row],
  });
}

async function publishTicketPanel(channel: TextChannel) {
  if (await channelHasPanel(channel, "Adamohub Support", "ticket:open:support")) return;
  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("ticket:open:support").setLabel("Support ticket").setEmoji("🛠️").setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId("ticket:open:payment").setLabel("Payment ticket").setEmoji("💳").setStyle(ButtonStyle.Secondary),
  );
  await channel.send({
    embeds: [
      new EmbedBuilder()
        .setColor(COLORS.purple)
        .setTitle("Adamohub Support")
        .setDescription("Need help? Choose a ticket type below. A private ticket channel will be created for you.")
        .addFields(
          { name: "Support", value: "General questions, bugs, account help, and community support.", inline: true },
          { name: "Payment", value: "Purchases, keys, subscriptions, and payment questions.", inline: true },
        ),
    ],
    components: [row],
  });
}

async function publishReactionRoles(channel: TextChannel) {
  if (await channelHasPanel(channel, "Notification roles", "reaction-roles")) return;
  const menu = new StringSelectMenuBuilder()
    .setCustomId("reaction-roles")
    .setPlaceholder("Choose notification roles")
    .setMinValues(0)
    .setMaxValues(4)
    .addOptions(
      NOTIFICATION_ROLES.map((role) =>
        new StringSelectMenuOptionBuilder()
          .setLabel(role.label)
          .setValue(role.key)
          .setDescription(role.description),
      ),
    );
  await channel.send({
    embeds: [
      new EmbedBuilder()
        .setColor(COLORS.blue)
        .setTitle("Notification roles")
        .setDescription("Select the pings you want to receive. You can change them at any time."),
    ],
    components: [new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(menu)],
  });
}

async function channelHasPanel(channel: TextChannel, title: string, customId?: string) {
  const messages = await channel.messages.fetch({ limit: 100 });
  return messages.some(
    (message) =>
      message.author.id === client.user?.id &&
      message.embeds.some((embed) => embed.title === title) &&
      (!customId ||
        message.components.some((row) =>
          "components" in row &&
          row.components.some((component) => "customId" in component && component.customId === customId),
        )),
  );
}

async function publishSetupPanels(guild: Guild, setup: Awaited<ReturnType<typeof setupGuild>>) {
  const welcome = getTextChannel(guild, setup.channels[CHANNEL_KEYS.welcome]);
  const support = getTextChannel(guild, setup.channels[CHANNEL_KEYS.support]);
  const verification = getTextChannel(guild, setup.channels[CHANNEL_KEYS.verification]);
  const notificationRoles = getTextChannel(guild, setup.channels[CHANNEL_KEYS.notificationRoles]);
  if (welcome && !(await channelHasPanel(welcome, "Welcome to Adamohub"))) {
    await welcome.send({
      embeds: [
        new EmbedBuilder()
          .setColor(COLORS.purple)
          .setTitle("Welcome to Adamohub")
          .setDescription("Welcome messages will appear here when a new member joins."),
      ],
    });
  }
  if (support) await publishTicketPanel(support);
  if (verification) await publishVerification(guild, verification);
  if (notificationRoles) await publishReactionRoles(notificationRoles);
}

async function createTicketChannel(interaction: ButtonInteraction, type: TicketType) {
  const guild = interaction.guild;
  if (!guild) return;
  const openTicketCount = await getOpenTicketCount(guild.id, interaction.user.id);
  if (openTicketCount >= 2) {
    await interaction.reply({
      content: "You can have a maximum of 2 open tickets at the same time. Close one before opening another.",
      ephemeral: true,
    });
    return;
  }
  const existing = guild.channels.cache.find(
    (channel) =>
      channel.name.startsWith(`🎫・${type}-`) &&
      channel.permissionsFor(interaction.user)?.has(PermissionFlagsBits.ViewChannel),
  );
  if (existing) {
    await interaction.reply({ content: `You already have an open ${type} ticket: ${existing}`, ephemeral: true });
    return;
  }
  const setup = await getSetup(guild.id);
  if (!setup) {
    await interaction.reply({ content: "The server has not been set up yet. Ask staff to run /setup.", ephemeral: true });
    return;
  }
  const staffRoleIds: string[] = Object.entries(setup.roleIds)
    .filter(([name]) => STAFF_ROLES.includes(name as (typeof STAFF_ROLES)[number]))
    .map(([, roleId]) => String(roleId));
  const channel = await guild.channels.create({
    name: `🎫・${type}-${interaction.user.username}`
      .toLowerCase()
      .replace(/[^a-z0-9-🎫・]/g, "-")
      .slice(0, 90),
    type: ChannelType.GuildText,
    parent: setup.config.categories && typeof setup.config.categories === "object"
      ? String((setup.config.categories as Record<string, unknown>).ticketCategory ?? "")
      : undefined,
    permissionOverwrites: [
      { id: guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
      { id: interaction.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.AttachFiles] },
      ...staffRoleIds.map((id) => ({ id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.ManageMessages] })),
    ],
    reason: `${type} ticket created by ${interaction.user.tag}`,
  });
  const ticket = await createTicket(guild.id, channel.id, type, interaction.user.id);
  const controls = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("ticket:claim").setLabel("Claim").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId("ticket:close").setLabel("Close ticket").setStyle(ButtonStyle.Primary),
  );
  const priorityMenu = new StringSelectMenuBuilder()
    .setCustomId("ticket:priority")
    .setPlaceholder("Choose ticket priority")
    .addOptions(
      { label: "Low", value: "low", description: "Set low priority", emoji: "🟢" },
      { label: "Normal", value: "normal", description: "Set normal priority", emoji: "🟡" },
      { label: "High", value: "high", description: "Set high priority", emoji: "🔴" },
    );
  const priorityControls = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(priorityMenu);
  await channel.send({
    content: `${interaction.user} <@&${setup.roleIds.Moderator}>`,
    embeds: [
      new EmbedBuilder()
        .setColor(COLORS.purple)
        .setTitle(`${type === "payment" ? "Payment" : "Support"} ticket #${ticket.ticketNumber}`)
        .setDescription("Please explain what you need help with. A staff member will be with you shortly.")
        .addFields(
          { name: "Ticket owner", value: `<@${interaction.user.id}>`, inline: true },
          { name: "Claim status", value: "Unclaimed", inline: true },
          { name: "Priority", value: "Normal", inline: true },
        ),
    ],
    components: [controls, priorityControls],
  });
  await interaction.reply({ content: `Your ticket is ready: ${channel}`, ephemeral: true });
  await logStaff(guild, `${interaction.user} created ${type} ticket #${ticket.ticketNumber}.`);
}

async function renameTicketChannel(channel: TextChannel | null, priority: TicketPriority) {
  if (!channel) return;
  const prefix =
    priority === "high"
      ? "🔴・high-priority-"
      : priority === "low"
        ? "🟢・low-priority-"
        : "🟡・normal-priority-";
  const baseName = channel.name.replace(/^(?:🔴・high-priority-|🟢・low-priority-|🟡・normal-priority-)/, "");
  const nextName = `${prefix}${baseName}`.slice(0, 100);
  if (channel.name !== nextName) {
    await channel.setName(nextName, `Ticket priority changed to ${priority}`);
  }
}

function isTicketChannel(channel: TextChannel) {
  return /^(?:🔴・high-priority-|🟢・low-priority-|🟡・normal-priority-)?🎫・(?:support|payment)-/.test(channel.name);
}

function ticketPriorityRank(channel: TextChannel) {
  if (channel.name.startsWith("🔴・high-priority-")) return 0;
  if (channel.name.startsWith("🟢・low-priority-")) return 2;
  return 1;
}

async function reorderTicketChannels(channel: TextChannel | null) {
  if (!channel?.parentId || !isTicketChannel(channel)) return;

  const siblings = [...channel.guild.channels.cache.values()]
    .filter(
      (candidate): candidate is TextChannel =>
        candidate.type === ChannelType.GuildText && candidate.parentId === channel.parentId,
    )
    .sort((a, b) => a.rawPosition - b.rawPosition);
  const ticketChannels = siblings
    .filter(isTicketChannel)
    .sort((a, b) => ticketPriorityRank(a) - ticketPriorityRank(b) || a.rawPosition - b.rawPosition);
  const ticketIds = new Set(ticketChannels.map((ticketChannel) => ticketChannel.id));
  let ticketIndex = 0;
  const desiredOrder = siblings.map((sibling) =>
    ticketIds.has(sibling.id) ? ticketChannels[ticketIndex++] : sibling,
  );
  const desiredPosition = desiredOrder.findIndex((sibling) => sibling.id === channel.id);

  if (desiredPosition >= 0 && siblings.findIndex((sibling) => sibling.id === channel.id) !== desiredPosition) {
    await channel.setPosition(desiredPosition, { reason: "Sort ticket channels by priority" });
  }
}

async function closeCurrentTicket(interaction: ChatInputCommandInteraction | ButtonInteraction) {
  const guild = interaction.guild;
  if (!guild || !isStaffMember(interaction.member as GuildMember | null)) {
    await interaction.reply({ content: "Only staff can close tickets.", ephemeral: true });
    return;
  }
  const ticket = await getTicket(interaction.channelId);
  if (!ticket) {
    await interaction.reply({ content: "This is not a tracked ticket channel.", ephemeral: true });
    return;
  }
  await updateTicket(interaction.channelId, { status: "closed", closedAt: new Date(), lastActivityAt: new Date() });
  await interaction.reply({
    embeds: [new EmbedBuilder().setColor(COLORS.warning).setTitle("Ticket closed").setDescription("This ticket is closed. Staff can reopen it or delete it to archive the transcript.")],
    components: [
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder().setCustomId("ticket:reopen").setLabel("Reopen ticket").setStyle(ButtonStyle.Success),
        new ButtonBuilder().setCustomId("ticket:delete").setLabel("Delete & archive").setStyle(ButtonStyle.Danger),
      ),
    ],
  });
  await logStaff(guild, `${interaction.user} closed ticket #${ticket.ticketNumber}.`, COLORS.warning);
}

async function reopenCurrentTicket(interaction: ChatInputCommandInteraction | ButtonInteraction) {
  const guild = interaction.guild;
  const ticket = await getTicket(interaction.channelId);
  if (!guild || !ticket || !isStaffMember(interaction.member as GuildMember | null)) {
    await interaction.reply({ content: "Only staff can reopen tracked tickets.", ephemeral: true });
    return;
  }
  await updateTicket(interaction.channelId, { status: "open", closedAt: null, lastActivityAt: new Date() });
  await interaction.reply({ content: "Ticket reopened. Staff can continue helping here." });
  await logStaff(guild, `${interaction.user} reopened ticket #${ticket.ticketNumber}.`, COLORS.success);
}

async function deleteCurrentTicket(interaction: ButtonInteraction) {
  const guild = interaction.guild;
  const channel = interaction.channel;
  const ticket = await getTicket(interaction.channelId);
  if (!guild || !ticket || !channel || channel.type !== ChannelType.GuildText || !isStaffMember(interaction.member as GuildMember | null)) {
    await interaction.reply({ content: "Only staff can delete tracked tickets.", ephemeral: true });
    return;
  }
  const setup = await getSetup(guild.id);
  const review = getTextChannel(guild, setup?.channelIds?.[CHANNEL_KEYS.ticketReview]);
  if (review) await sendTranscript(review, channel, "Ticket deleted by staff");
  await interaction.reply({ content: "The transcript has been archived. Deleting this ticket now.", ephemeral: true });
  await updateTicket(interaction.channelId, { status: "deleted", closedAt: new Date() });
  await logStaff(guild, `${interaction.user} deleted and archived ticket #${ticket.ticketNumber}.`, COLORS.danger);
  await channel.delete("Ticket transcript archived");
}

async function handleWarning(interaction: ChatInputCommandInteraction) {
  const guild = interaction.guild;
  const member = interaction.options.getMember("user");
  const reason = interaction.options.getString("reason", true);
  if (!guild || !(member instanceof GuildMember) || !isStaffMember(interaction.member as GuildMember | null)) {
    await interaction.reply({ content: "Only staff can warn server members.", ephemeral: true });
    return;
  }
  const warning = await addWarning(guild.id, member.id, interaction.user.id, reason);
  let escalation = "No automatic escalation.";
  if (warning.warningNumber === 2) {
    await member.timeout(5 * 60 * 1000, reason);
    escalation = "The member received a 5-minute timeout.";
  } else if (warning.warningNumber === 3) {
    await member.timeout(60 * 60 * 1000, reason);
    escalation = "The member received a 1-hour timeout.";
  } else if (warning.warningNumber === 4 || warning.warningNumber === 5) {
    await member.kick(reason);
    escalation = "The member was kicked.";
  } else if (warning.warningNumber >= 6) {
    await member.ban({ reason });
    escalation = "The member was banned.";
  }
  await interaction.reply({
    embeds: [
      new EmbedBuilder()
        .setColor(COLORS.warning)
        .setTitle("Warning issued")
        .setDescription(`${member} received warning **#${warning.warningNumber}**.`)
        .addFields({ name: "Reason", value: reason }, { name: "Escalation", value: escalation }),
    ],
  });
  await logStaff(guild, `${interaction.user} warned ${member.user.tag} (#${warning.warningNumber}). Reason: ${reason}\n${escalation}`, COLORS.warning);
}

async function handleRemoveWarning(interaction: ChatInputCommandInteraction) {
  const guild = interaction.guild;
  const user = interaction.options.getUser("user", true);
  const warningNumber = interaction.options.getInteger("warning", true);
  const reason = interaction.options.getString("reason") ?? "No reason provided.";
  if (!guild) return;

  const warning = await removeWarning(guild.id, user.id, warningNumber);
  if (!warning) {
    await interaction.reply({
      content: `Warning **#${warningNumber}** was not found for ${user.tag}.`,
      ephemeral: true,
    });
    return;
  }

  await interaction.reply({
    embeds: [
      new EmbedBuilder()
        .setColor(COLORS.success)
        .setTitle("Warning removed")
        .setDescription(`Warning **#${warningNumber}** was removed from ${user}.`)
        .addFields(
          { name: "Original reason", value: warning.reason },
          { name: "Removed by", value: `${interaction.user}` },
          { name: "Removal reason", value: reason },
        )
        .setTimestamp(),
    ],
  });
  await logStaff(
    guild,
    `${interaction.user} removed warning #${warningNumber} from ${user.tag}.\nReason: ${reason}`,
    COLORS.success,
  );
}

async function handleCommand(interaction: ChatInputCommandInteraction) {
  const guild = interaction.guild;
  if (!guild) return;
  const member = interaction.member instanceof GuildMember ? interaction.member : null;
  const command = interaction.commandName;

  if (command === "setup") {
    if (!member || !isBotOperator(member, guild)) {
      await interaction.reply({ content: "Only the server owner or Developer/Owner role can use Adamohub.", ephemeral: true });
      return;
    }
    await interaction.deferReply({ ephemeral: true });
    const setup = await setupGuild(guild, interaction.user.id);
    if (guild.ownerId === interaction.user.id) {
      const ownerRole = getRole(guild, setup.roles.Owner);
      if (ownerRole && member) await member.roles.add(ownerRole, "Adamohub server owner role");
    }
    await publishSetupPanels(guild, setup);
    await interaction.editReply("Adamohub server setup complete. Categories, roles, permissions, verification, tickets, and notification panels are ready.");
    await logStaff(guild, `${interaction.user} completed the Adamohub server setup.`, COLORS.success);
    return;
  }

  if (command === "test") {
    const setup = await getSetup(guild.id);
    const channel = getTextChannel(guild, setup?.channelIds?.[CHANNEL_KEYS.welcome]);
    if (!channel) {
      await interaction.reply({ content: "Run /setup first so I know where to send the welcome preview.", ephemeral: true });
      return;
    }
    await sendWelcome(channel, member ?? (await guild.members.fetch(interaction.user.id)));
    await interaction.reply({ content: "Welcome preview sent.", ephemeral: true });
    return;
  }

  if (command === "status") {
    await interaction.reply({
      embeds: [
        new EmbedBuilder()
          .setColor(COLORS.success)
          .setTitle("Adamohub status")
          .setDescription("All core services are online.")
          .addFields(
            { name: "Bot", value: "Online", inline: true },
            { name: "Tickets", value: "Operational", inline: true },
            { name: "Moderation", value: "Operational", inline: true },
          )
          .setTimestamp(),
      ],
    });
    return;
  }

  if (command === "setstatus" || command === "changelog") {
    const text = interaction.options.getString("message", true);
    const setup = await getSetup(guild.id);
    const key = command === "setstatus" ? CHANNEL_KEYS.status : CHANNEL_KEYS.changelog;
    const channel = getTextChannel(guild, setup?.channelIds?.[key]);
    if (!channel) {
      await interaction.reply({ content: "Run /setup first so I know where to publish this.", ephemeral: true });
      return;
    }
    await channel.send({
      embeds: [
        new EmbedBuilder()
          .setColor(command === "setstatus" ? COLORS.success : COLORS.purple)
          .setTitle(command === "setstatus" ? "Adamohub status update" : "Changelog")
          .setDescription(text)
          .setFooter({ text: `Published by ${interaction.user.tag}` })
          .setTimestamp(),
      ],
    });
    await interaction.reply({ content: `Published in ${channel}.`, ephemeral: true });
    await logStaff(guild, `${interaction.user} published a ${command === "setstatus" ? "status" : "changelog"} message.`);
    return;
  }

  if (command === "userinfo") {
    const user = interaction.options.getUser("user") ?? interaction.user;
    const target = await guild.members.fetch(user.id);
    const warnings = await listWarnings(guild.id, user.id);
    const setup = await getSetup(guild.id);
    const verifiedRoleId = setup?.roleIds?.Verified;
    const tickets = await import("./db").then(({ getTicketCount }) => getTicketCount(guild.id, user.id));
    await interaction.reply({
      embeds: [
        new EmbedBuilder()
          .setColor(COLORS.blue)
          .setTitle(`User info: ${user.tag}`)
          .setThumbnail(user.displayAvatarURL())
          .addFields(
            { name: "Roles", value: target.roles.cache.filter((role) => role.id !== guild.id).map((role) => role.toString()).join(", ") || "None" },
            { name: "Joined", value: `<t:${Math.floor((target.joinedTimestamp ?? Date.now()) / 1000)}:F>`, inline: true },
            { name: "Account age", value: `<t:${Math.floor(user.createdTimestamp / 1000)}:R>`, inline: true },
            { name: "Warnings", value: String(warnings.length), inline: true },
            { name: "Verification", value: verifiedRoleId && target.roles.cache.has(verifiedRoleId) ? "Verified" : "Not verified", inline: true },
            { name: "Tickets", value: String(tickets), inline: true },
          ),
      ],
    });
    return;
  }

  if (command === "warn") {
    await handleWarning(interaction);
    return;
  }

  if (command === "warnings") {
    const user = interaction.options.getUser("user", true);
    const warnings = await listWarnings(guild.id, user.id);
    await interaction.reply({
      embeds: [
        new EmbedBuilder()
          .setColor(COLORS.warning)
          .setTitle(`Warnings for ${user.tag}`)
          .setDescription(warnings.length ? warnings.map((warning) => `**#${warning.warningNumber}** <t:${Math.floor(warning.createdAt.getTime() / 1000)}:d> — ${warning.reason} (by <@${warning.moderatorId}>)`).join("\n") : "No warnings recorded."),
      ],
    });
    return;
  }

  if (command === "removewarn") {
    await handleRemoveWarning(interaction);
    return;
  }

  if (command === "kick" || command === "ban" || command === "timeout") {
    const target = interaction.options.getMember("user");
    const reason = interaction.options.getString("reason", true);
    if (!(target instanceof GuildMember)) {
      await interaction.reply({ content: "That member is not in this server.", ephemeral: true });
      return;
    }
    if (command === "kick") await target.kick(reason);
    if (command === "ban") await target.ban({ reason });
    if (command === "timeout") await target.timeout(interaction.options.getInteger("minutes", true) * 60 * 1000, reason);
    await interaction.reply({ content: `${target.user.tag} was ${command === "timeout" ? "timed out" : `${command}ed`} successfully.` });
    await logStaff(guild, `${interaction.user} used /${command} on ${target.user.tag}. Reason: ${reason}`, COLORS.danger);
    return;
  }

  if (command === "clear") {
    if (!interaction.channel || interaction.channel.type !== ChannelType.GuildText) {
      await interaction.reply({ content: "This command can only run in a text channel.", ephemeral: true });
      return;
    }
    const amount = interaction.options.getInteger("amount", true);
    await interaction.channel.bulkDelete(amount, true);
    await interaction.reply({ content: `Deleted ${amount} messages.`, ephemeral: true });
    await logStaff(guild, `${interaction.user} deleted ${amount} messages in ${interaction.channel}.`, COLORS.warning);
    return;
  }

  if (command === "create") {
    const minutes = interaction.options.getInteger("minutes", true);
    const winners = interaction.options.getInteger("winners", true);
    const prize = interaction.options.getString("prize", true);
    const channel = getTextChannel(guild, (await getSetup(guild.id))?.channelIds?.[CHANNEL_KEYS.giveaways]) ?? (interaction.channel?.type === ChannelType.GuildText ? interaction.channel : undefined);
    if (!channel) {
      await interaction.reply({ content: "Run /setup first so I know where to publish giveaways.", ephemeral: true });
      return;
    }
    const endsAt = new Date(Date.now() + minutes * 60 * 1000);
    const message = await channel.send({
      embeds: [
        new EmbedBuilder()
          .setColor(COLORS.purple)
          .setTitle("Giveaway")
          .setDescription(`React with 🎉 to enter.\n\n**Prize:** ${prize}\n**Winners:** ${winners}\n**Ends:** <t:${Math.floor(endsAt.getTime() / 1000)}:R>`)
          .setFooter({ text: `Started by ${interaction.user.tag}` }),
      ],
    });
    await message.react("🎉");
    await createGiveaway({ guildId: guild.id, channelId: channel.id, messageId: message.id, prize, winnerCount: winners, endsAt, createdBy: interaction.user.id });
    await interaction.reply({ content: `Giveaway created in ${channel}.`, ephemeral: true });
    return;
  }

  if (command === "verification" || command === "ticket" || command === "reactionroles") {
    const setup = await getSetup(guild.id);
    if (!setup) {
      await interaction.reply({ content: "Run /setup first.", ephemeral: true });
      return;
    }
    const key =
      command === "verification"
        ? CHANNEL_KEYS.verification
        : command === "ticket"
          ? CHANNEL_KEYS.support
          : CHANNEL_KEYS.notificationRoles;
    const channel = getTextChannel(guild, setup.channelIds[key]);
    if (!channel) {
      await interaction.reply({ content: "The configured channel is missing. Run /setup again.", ephemeral: true });
      return;
    }
    if (command === "verification") await publishVerification(guild, channel);
    if (command === "ticket") await publishTicketPanel(channel);
    if (command === "reactionroles") await publishReactionRoles(channel);
    await interaction.reply({ content: `Published the ${command} panel in ${channel}.`, ephemeral: true });
    return;
  }

  if (command === "close") return closeCurrentTicket(interaction);
  if (command === "reopen") return reopenCurrentTicket(interaction);
  if (command === "claim" || command === "priority") {
    const ticket = await getTicket(interaction.channelId);
    if (!ticket || !isStaffMember(member)) {
      await interaction.reply({ content: "This command is only available inside a tracked staff ticket.", ephemeral: true });
      return;
    }
    if (command === "claim") {
      await updateTicket(interaction.channelId, { claimedBy: interaction.user.id, lastActivityAt: new Date() });
      await interaction.reply({ content: `Ticket claimed by ${interaction.user}.` });
    } else {
      const priority = interaction.options.getString("level", true) as TicketPriority;
      await updateTicket(interaction.channelId, { priority, lastActivityAt: new Date() });
      if (interaction.channel?.type === ChannelType.GuildText) {
        await renameTicketChannel(interaction.channel, priority);
        await reorderTicketChannels(interaction.channel);
      }
      await interaction.reply({ content: `Ticket priority set to **${priority}**.` });
    }
    await logStaff(guild, `${interaction.user} updated ticket #${ticket.ticketNumber}: ${command}.`);
  }
}

async function handleButton(interaction: ButtonInteraction) {
  if (interaction.customId === "verify") {
    const guild = interaction.guild;
    if (!guild) return;
    const setup = await getSetup(guild.id);
    const verifiedRole = getRole(guild, setup?.roleIds?.Verified);
    if (!verifiedRole || !(interaction.member instanceof GuildMember)) {
      await interaction.reply({ content: "Verification is not configured yet. Ask staff to run /setup.", ephemeral: true });
      return;
    }
    await interaction.member.roles.add(verifiedRole, "Member completed Adamohub verification");
    await interaction.reply({ content: "You are verified. Welcome to Adamohub.", ephemeral: true });
    await logStaff(guild, `${interaction.user} verified themselves.`);
    return;
  }
  if (interaction.customId.startsWith("ticket:open:")) {
    await createTicketChannel(interaction, interaction.customId.endsWith("payment") ? "payment" : "support");
    return;
  }
  if (interaction.customId === "ticket:close") return closeCurrentTicket(interaction);
  if (interaction.customId === "ticket:reopen") return reopenCurrentTicket(interaction);
  if (interaction.customId === "ticket:delete") return deleteCurrentTicket(interaction);
  const ticket = await getTicket(interaction.channelId);
  if (!ticket || !interaction.guild || !isStaffMember(interaction.member as GuildMember | null)) {
    await interaction.reply({ content: "Only staff can update this ticket.", ephemeral: true });
    return;
  }
  if (interaction.customId === "ticket:claim") {
    await updateTicket(interaction.channelId, { claimedBy: interaction.user.id, lastActivityAt: new Date() });
    await interaction.reply({ content: `Ticket claimed by ${interaction.user}.` });
  } else if (interaction.customId.startsWith("ticket:priority:")) {
    const priority = interaction.customId.split(":")[2] as TicketPriority;
    await updateTicket(interaction.channelId, { priority, lastActivityAt: new Date() });
    await interaction.reply({ content: `Ticket priority set to **${priority}**.` });
    if (interaction.channel?.type === ChannelType.GuildText) {
      await renameTicketChannel(interaction.channel, priority);
      await reorderTicketChannels(interaction.channel);
    }
  }
  await logStaff(interaction.guild, `${interaction.user} updated ticket #${ticket.ticketNumber} using ${interaction.customId}.`);
}

function auditActionDescription(action: AuditLogEvent) {
  const descriptions: Partial<Record<AuditLogEvent, string>> = {
    [AuditLogEvent.GuildUpdate]: "updated the server",
    [AuditLogEvent.ChannelCreate]: "created a channel",
    [AuditLogEvent.ChannelUpdate]: "updated a channel",
    [AuditLogEvent.ChannelDelete]: "deleted a channel",
    [AuditLogEvent.ChannelOverwriteCreate]: "created a channel permission overwrite",
    [AuditLogEvent.ChannelOverwriteUpdate]: "updated a channel permission overwrite",
    [AuditLogEvent.ChannelOverwriteDelete]: "deleted a channel permission overwrite",
    [AuditLogEvent.MemberKick]: "kicked a member",
    [AuditLogEvent.MemberPrune]: "pruned members",
    [AuditLogEvent.MemberBanAdd]: "banned a member",
    [AuditLogEvent.MemberBanRemove]: "unbanned a member",
    [AuditLogEvent.MemberUpdate]: "updated a member",
    [AuditLogEvent.MemberRoleUpdate]: "changed a member's roles",
    [AuditLogEvent.MemberMove]: "moved a member",
    [AuditLogEvent.MemberDisconnect]: "disconnected a member",
    [AuditLogEvent.BotAdd]: "added a bot",
    [AuditLogEvent.RoleCreate]: "created a role",
    [AuditLogEvent.RoleUpdate]: "updated a role",
    [AuditLogEvent.RoleDelete]: "deleted a role",
    [AuditLogEvent.InviteCreate]: "created an invite",
    [AuditLogEvent.InviteUpdate]: "updated an invite",
    [AuditLogEvent.InviteDelete]: "deleted an invite",
    [AuditLogEvent.WebhookCreate]: "created a webhook",
    [AuditLogEvent.WebhookUpdate]: "updated a webhook",
    [AuditLogEvent.WebhookDelete]: "deleted a webhook",
    [AuditLogEvent.MessageDelete]: "deleted a message",
    [AuditLogEvent.MessageBulkDelete]: "deleted multiple messages",
    [AuditLogEvent.MessagePin]: "pinned a message",
    [AuditLogEvent.MessageUnpin]: "unpinned a message",
    [AuditLogEvent.IntegrationCreate]: "added an integration",
    [AuditLogEvent.IntegrationUpdate]: "updated an integration",
    [AuditLogEvent.IntegrationDelete]: "removed an integration",
    [AuditLogEvent.StageInstanceCreate]: "created a stage",
    [AuditLogEvent.StageInstanceUpdate]: "updated a stage",
    [AuditLogEvent.StageInstanceDelete]: "deleted a stage",
    [AuditLogEvent.ThreadCreate]: "created a thread",
    [AuditLogEvent.ThreadUpdate]: "updated a thread",
    [AuditLogEvent.ThreadDelete]: "deleted a thread",
  };
  return descriptions[action] ?? "performed a server administration action";
}

async function handleSelect(interaction: import("discord.js").StringSelectMenuInteraction) {
  if (interaction.customId === "ticket:priority") {
    const ticket = await getTicket(interaction.channelId);
    const member = interaction.member instanceof GuildMember ? interaction.member : null;
    if (!ticket || !interaction.guild || !isStaffMember(member)) {
      await interaction.reply({ content: "Only staff can update this ticket.", ephemeral: true });
      return;
    }
    const priority = interaction.values[0] as TicketPriority;
    await updateTicket(interaction.channelId, { priority, lastActivityAt: new Date() });
    if (interaction.channel?.type === ChannelType.GuildText) {
      await renameTicketChannel(interaction.channel, priority);
      await reorderTicketChannels(interaction.channel);
    }
    await interaction.reply({ content: `Ticket priority set to **${priority}**.` });
    await logStaff(interaction.guild, `${interaction.user} set ticket #${ticket.ticketNumber} to ${priority} priority.`);
    return;
  }

  if (interaction.customId !== "reaction-roles" || !(interaction.member instanceof GuildMember)) return;
  const selected = new Set(interaction.values);
  const roles = await Promise.all(NOTIFICATION_ROLES.map(async (definition) => {
    const existing = interaction.guild?.roles.cache.find((role) => role.name === definition.name);
    return existing ?? interaction.guild?.roles.create({
      name: definition.name,
      reason: "Adamohub notification role setup",
    });
  }));
  for (let index = 0; index < NOTIFICATION_ROLES.length; index += 1) {
    const role = roles[index];
    if (!role) continue;
    if (selected.has(NOTIFICATION_ROLES[index].key)) await interaction.member.roles.add(role);
    else await interaction.member.roles.remove(role);
  }
  await interaction.reply({ content: "Your notification roles have been updated.", ephemeral: true });
}

async function checkGiveaways() {
  const active = await getActiveGiveaways();
  for (const giveaway of active) {
    if (giveaway.endsAt.getTime() > Date.now()) continue;
    const channel = await client.channels.fetch(giveaway.channelId).catch(() => null);
    if (!channel || channel.type !== ChannelType.GuildText) {
      await finishGiveaway(giveaway.messageId);
      continue;
    }
    const message = await channel.messages.fetch(giveaway.messageId).catch(() => null);
    if (!message) {
      await finishGiveaway(giveaway.messageId);
      continue;
    }
    const reaction = message.reactions.cache.get("🎉");
    const users = reaction ? (await reaction.users.fetch()).filter((user) => !user.bot) : new Collection<string, User>();
    const pool = [...users.values()];
    const winners = pool.sort(() => Math.random() - 0.5).slice(0, Math.min(giveaway.winnerCount, pool.length));
    await channel.send({
      embeds: [
        new EmbedBuilder()
          .setColor(COLORS.success)
          .setTitle("Giveaway ended")
          .setDescription(winners.length ? `Congratulations ${winners.map((winner) => winner.toString()).join(", ")}!\n\n**Prize:** ${giveaway.prize}` : `No valid entries were found.\n\n**Prize:** ${giveaway.prize}`),
      ],
    });
    await finishGiveaway(giveaway.messageId);
  }
}

async function checkStaleTickets() {
  const stale = await listStaleTickets(new Date(Date.now() - 48 * 60 * 60 * 1000));
  for (const ticket of stale) {
    const channel = await client.channels.fetch(ticket.channelId).catch(() => null);
    if (!channel || channel.type !== ChannelType.GuildText) continue;
    await updateTicket(ticket.channelId, { status: "closed", closedAt: new Date(), lastActivityAt: new Date() });
    await channel.send({
      embeds: [
        new EmbedBuilder()
          .setColor(COLORS.warning)
          .setTitle("Ticket automatically closed")
          .setDescription("This ticket was closed after 48 hours without a reply. Staff can reopen it if needed."),
      ],
    });
  }
}

async function registerCommands() {
  if (!client.user) return;
  const rest = new REST({ version: "10" }).setToken(token as string);
  for (const guild of client.guilds.cache.values()) {
    await rest.put(Routes.applicationGuildCommands(client.user.id, guild.id), { body: commands });
  }
}

export function startDiscordBot() {
  if (!token) {
    logger.warn("DISCORD_BOT_TOKEN is not configured; Discord bot is disabled.");
    return;
  }
  client.once("clientReady", async (readyClient) => {
    await registerCommands();
    logger.info({ user: readyClient.user.tag, guilds: readyClient.guilds.cache.size }, "Adamohub Discord bot is online");
    setInterval(() => void checkGiveaways().catch((error: unknown) => logger.error({ error }, "Giveaway check failed")), 30_000);
    setInterval(() => void checkStaleTickets().catch((error: unknown) => logger.error({ error }, "Ticket auto-close check failed")), 5 * 60_000);
  });
  client.on("guildMemberAdd", async (member) => {
    const setup = await getSetup(member.guild.id);
    const channel = getTextChannel(member.guild, setup?.channelIds?.[CHANNEL_KEYS.welcome]);
    if (channel) await sendWelcome(channel, member);
    const role = getRole(member.guild, setup?.roleIds?.Member);
    if (role) await member.roles.add(role, "Default Adamohub member role");
  });
  client.on("messageCreate", async (message: Message) => {
    if (message.author.bot || !message.guild) return;
    const ticket = await getTicket(message.channelId);
    if (ticket) await updateTicket(message.channelId, { lastActivityAt: new Date() });
    const normalized = message.content.trim().toLowerCase();
    if (normalized.length > 10) {
      const key = `${message.guild.id}:${message.author.id}:${normalized}`;
      const times = [...(duplicateMessages.get(key) ?? []), Date.now()].filter((time) => Date.now() - time < 15_000);
      duplicateMessages.set(key, times);
      if (times.length >= 3 && message.deletable) {
        await message.delete().catch(() => undefined);
        await logStaff(message.guild, `Anti-raid removed repeated messages from ${message.author}.`, COLORS.danger);
      }
    }
  });
  client.on("interactionCreate", async (interaction) => {
    try {
      if (interaction.guild) {
        const member =
          interaction.member instanceof GuildMember
            ? interaction.member
            : await interaction.guild.members.fetch(interaction.user.id).catch(() => null);
        if (!isBotOperator(member, interaction.guild)) {
          if (interaction.isRepliable()) {
            await interaction.reply({
              content: "Only the server owner or the Developer/Owner role can use Adamohub.",
              ephemeral: true,
            });
          }
          return;
        }
      }
      if (interaction.isChatInputCommand()) await handleCommand(interaction);
      else if (interaction.isButton()) await handleButton(interaction);
      else if (interaction.isStringSelectMenu()) await handleSelect(interaction);
    } catch (error) {
      logger.error({ error }, "Discord interaction failed");
      const response = { content: "Something went wrong while handling that request.", ephemeral: true };
      if (interaction.isRepliable()) {
        if (interaction.replied || interaction.deferred) await interaction.followUp(response).catch(() => undefined);
        else await interaction.reply(response).catch(() => undefined);
      }
    }
  });
  client.on("guildAuditLogEntryCreate", async (entry, guild) => {
    if (!entry.executor || entry.executor.bot) return;
    const target = entry.target?.toString() ?? (entry.targetId ? `ID ${entry.targetId}` : "an unknown target");
    const timestamp = Math.floor((entry.createdTimestamp ?? Date.now()) / 1000);
    await logStaff(
      guild,
      `${entry.executor} ${auditActionDescription(entry.action)}: ${target}.\nWhen: <t:${timestamp}:F>`,
    );
  });
  client.login(token).catch((error: unknown) => logger.error({ error }, "Discord bot login failed"));
}