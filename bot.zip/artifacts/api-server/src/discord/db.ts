import { and, desc, eq, sql } from "drizzle-orm";
import {
  db,
  discordGiveaways,
  discordGuilds,
  discordTickets,
  discordWarnings,
  type DiscordTicket,
} from "@workspace/db";
import type { SetupIds, TicketPriority, TicketType } from "./types";

export async function saveSetup(
  guildId: string,
  ownerId: string,
  setup: SetupIds,
) {
  await db
    .insert(discordGuilds)
    .values({
      guildId,
      ownerId,
      channelIds: setup.channels,
      roleIds: setup.roles,
      config: { categories: setup.categories },
      updatedAt: new Date(),
    })
    .onConflictDoUpdate({
      target: discordGuilds.guildId,
      set: {
        ownerId,
        channelIds: setup.channels,
        roleIds: setup.roles,
        config: { categories: setup.categories },
        updatedAt: new Date(),
      },
    });
}

export async function getSetup(guildId: string) {
  const [setup] = await db
    .select()
    .from(discordGuilds)
    .where(eq(discordGuilds.guildId, guildId))
    .limit(1);
  return setup;
}

export async function resetGuildData(guildId: string) {
  await db.delete(discordWarnings).where(eq(discordWarnings.guildId, guildId));
  await db.delete(discordTickets).where(eq(discordTickets.guildId, guildId));
  await db.delete(discordGiveaways).where(eq(discordGiveaways.guildId, guildId));
}

export async function addWarning(
  guildId: string,
  userId: string,
  moderatorId: string,
  reason: string,
) {
  const [{ maxWarningNumber }] = await db
    .select({ maxWarningNumber: sql<number | null>`max(${discordWarnings.warningNumber})` })
    .from(discordWarnings)
    .where(and(eq(discordWarnings.guildId, guildId), eq(discordWarnings.userId, userId)));
  const warningNumber = Number(maxWarningNumber ?? 0) + 1;
  const [warning] = await db
    .insert(discordWarnings)
    .values({ guildId, userId, moderatorId, reason, warningNumber })
    .returning();
  return warning;
}

export async function removeWarning(guildId: string, userId: string, warningNumber: number) {
  const [warning] = await db
    .delete(discordWarnings)
    .where(
      and(
        eq(discordWarnings.guildId, guildId),
        eq(discordWarnings.userId, userId),
        eq(discordWarnings.warningNumber, warningNumber),
      ),
    )
    .returning();
  return warning;
}

export async function listWarnings(guildId: string, userId: string) {
  return db
    .select()
    .from(discordWarnings)
    .where(and(eq(discordWarnings.guildId, guildId), eq(discordWarnings.userId, userId)))
    .orderBy(desc(discordWarnings.createdAt));
}

export async function getTicketCount(guildId: string, ownerId: string) {
  const [{ count }] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(discordTickets)
    .where(and(eq(discordTickets.guildId, guildId), eq(discordTickets.ownerId, ownerId)));
  return Number(count);
}

export async function getOpenTicketCount(guildId: string, ownerId: string) {
  const [{ count }] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(discordTickets)
    .where(
      and(
        eq(discordTickets.guildId, guildId),
        eq(discordTickets.ownerId, ownerId),
        eq(discordTickets.status, "open"),
      ),
    );
  return Number(count);
}

export async function createTicket(
  guildId: string,
  channelId: string,
  type: TicketType,
  ownerId: string,
) {
  const [{ max }] = await db
    .select({ max: sql<number | null>`max(${discordTickets.ticketNumber})` })
    .from(discordTickets)
    .where(eq(discordTickets.guildId, guildId));
  const ticketNumber = Number(max ?? 0) + 1;
  const [ticket] = await db
    .insert(discordTickets)
    .values({ guildId, channelId, type, ownerId, ticketNumber })
    .returning();
  return ticket;
}

export async function getTicket(channelId: string) {
  const [ticket] = await db
    .select()
    .from(discordTickets)
    .where(eq(discordTickets.channelId, channelId))
    .limit(1);
  return ticket;
}

export async function updateTicket(
  channelId: string,
  values: Partial<{
    claimedBy: string | null;
    priority: TicketPriority;
    status: string;
    lastActivityAt: Date;
    closedAt: Date | null;
  }>,
) {
  const [ticket] = await db
    .update(discordTickets)
    .set(values)
    .where(eq(discordTickets.channelId, channelId))
    .returning();
  return ticket;
}

export async function listStaleTickets(cutoff: Date) {
  return db
    .select()
    .from(discordTickets)
    .where(and(eq(discordTickets.status, "open"), sql`${discordTickets.lastActivityAt} < ${cutoff}`));
}

export async function createGiveaway(values: {
  guildId: string;
  channelId: string;
  messageId: string;
  prize: string;
  winnerCount: number;
  endsAt: Date;
  createdBy: string;
}) {
  const [giveaway] = await db.insert(discordGiveaways).values(values).returning();
  return giveaway;
}

export async function getActiveGiveaways() {
  return db
    .select()
    .from(discordGiveaways)
    .where(eq(discordGiveaways.ended, false));
}

export async function finishGiveaway(messageId: string) {
  await db
    .update(discordGiveaways)
    .set({ ended: true })
    .where(eq(discordGiveaways.messageId, messageId));
}

export function ticketIsOpen(ticket: DiscordTicket | undefined) {
  return ticket?.status === "open";
}