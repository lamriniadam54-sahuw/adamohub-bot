export const COLORS: Record<"purple" | "success" | "warning" | "danger" | "blue", number> = {
  purple: 0x8b5cf6,
  success: 0x22c55e,
  warning: 0xf59e0b,
  danger: 0xef4444,
  blue: 0x3b82f6,
} as const;

export const ROLE_NAMES = [
  "Owner",
  "Developer",
  "Admin",
  "Moderator",
  "Premium",
  "Verified",
  "Member",
] as const;

export const STAFF_ROLES = ["Owner", "Developer", "Admin", "Moderator"] as const;

export const ROLE_DEFINITIONS: Record<(typeof ROLE_NAMES)[number], string> = {
  Owner: "👑・Owner",
  Developer: "⚡・Developer",
  Admin: "🛡️・Admin",
  Moderator: "🔨・Moderator",
  Premium: "💎・Premium",
  Verified: "⭐・Verified",
  Member: "👤・Member",
};

export const NOTIFICATION_ROLES = [
  { key: "Changelog Ping", name: "📜・Changelog Ping", label: "Changelog ping", description: "Get notified about changelogs." },
  { key: "Giveaway Ping", name: "🎉・Giveaway Ping", label: "Giveaway ping", description: "Get notified about giveaways." },
  { key: "Status Ping", name: "📊・Status Ping", label: "Status ping", description: "Get notified about status updates." },
  { key: "Key Ping", name: "🔑・Key Ping", label: "Key ping", description: "Get notified when keys are available." },
] as const;

export function roleKeyFromName(name: string) {
  const entry = Object.entries(ROLE_DEFINITIONS).find(([, displayName]) => displayName === name);
  return entry?.[0] ?? name;
}

export const CHANNEL_KEYS = {
  welcome: "welcome",
  rules: "rules",
  announcements: "announcements",
  notificationRoles: "notification-roles",
  getKey: "get-key",
  status: "status",
  scriptInfo: "script-info",
  updates: "updates",
  supportedGames: "supported-games",
  changelog: "changelog",
  general: "general",
  suggestions: "suggestions",
  bugReports: "bug-reports",
  support: "support",
  media: "media",
  reports: "reports",
  staffChat: "staff-chat",
  staffLogs: "staff-logs",
  ticketReview: "ticket-review",
  verification: "verification",
  giveaways: "giveaways",
  ticketCategory: "tickets",
  publicVoice: "community-voice",
  gamingVoice: "gaming-voice",
  staffVoice: "staff-voice",
} as const;