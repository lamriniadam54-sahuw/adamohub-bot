---
name: Discord bot connection boundary
description: The Replit Discord OAuth connection cannot perform gateway bot actions; message-handling requires a Discord bot token secret.
---

The Discord integration's OAuth connection is useful for user-level Discord API access, but it does not replace a Discord application's bot token for gateway login or channel/role/message management.

**Why:** Discord enforces a token-type boundary; the OAuth connection can return 401/403 for the bot operations this project needs.

**How to apply:** Keep bot runtime authentication in the `DISCORD_BOT_TOKEN` project secret and do not put the token in chat or source files.