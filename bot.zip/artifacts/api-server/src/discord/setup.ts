import {
  ChannelType,
  PermissionFlagsBits,
  type CategoryChannel,
  type Guild,
  type GuildBasedChannel,
  type Role,
  type TextChannel,
} from "discord.js";
import {
  CHANNEL_KEYS,
  ROLE_DEFINITIONS,
  ROLE_NAMES,
  STAFF_ROLES,
  roleKeyFromName,
} from "./constants";
import { saveSetup } from "./db";
import type { SetupIds } from "./types";

const CATEGORY_NAMES = {
  information: "📌・INFORMATION",
  adamohub: "💻・ADAMOHUB",
  community: "💬・COMMUNITY",
  staff: "🔒・STAFF",
  ticketCategory: "🎫・TICKETS",
} as const;

const channelDefinitions = [
  { key: CHANNEL_KEYS.welcome, name: "👋・welcome", category: "information", type: ChannelType.GuildText },
  { key: CHANNEL_KEYS.rules, name: "📜・rules", category: "information", type: ChannelType.GuildText },
  { key: CHANNEL_KEYS.announcements, name: "📢・announcements", category: "information", type: ChannelType.GuildText },
  { key: CHANNEL_KEYS.notificationRoles, name: "🔔・notification-roles", category: "information", type: ChannelType.GuildText },
  { key: CHANNEL_KEYS.getKey, name: "🔑・get-key", category: "information", type: ChannelType.GuildText },
  { key: CHANNEL_KEYS.status, name: "📊・status", category: "information", type: ChannelType.GuildText },
  { key: CHANNEL_KEYS.verification, name: "✅・verification", category: "information", type: ChannelType.GuildText },
  { key: CHANNEL_KEYS.scriptInfo, name: "📜・script-info", category: "adamohub", type: ChannelType.GuildText },
  { key: CHANNEL_KEYS.updates, name: "🆕・updates", category: "adamohub", type: ChannelType.GuildText },
  { key: CHANNEL_KEYS.supportedGames, name: "🎮・supported-games", category: "adamohub", type: ChannelType.GuildText },
  { key: CHANNEL_KEYS.changelog, name: "📖・changelog", category: "adamohub", type: ChannelType.GuildText },
  { key: CHANNEL_KEYS.general, name: "💬・general", category: "community", type: ChannelType.GuildText },
  { key: CHANNEL_KEYS.suggestions, name: "💡・suggestions", category: "community", type: ChannelType.GuildForum },
  { key: CHANNEL_KEYS.bugReports, name: "🐛・bug-reports", category: "community", type: ChannelType.GuildForum },
  { key: CHANNEL_KEYS.support, name: "❓・support", category: "community", type: ChannelType.GuildText },
  { key: CHANNEL_KEYS.media, name: "📸・media", category: "community", type: ChannelType.GuildText },
  { key: CHANNEL_KEYS.reports, name: "🚨・reports", category: "community", type: ChannelType.GuildForum },
  { key: CHANNEL_KEYS.giveaways, name: "🎁・giveaways", category: "community", type: ChannelType.GuildText },
  { key: CHANNEL_KEYS.publicVoice, name: "🔊・community-voice", category: "community", type: ChannelType.GuildVoice },
  { key: CHANNEL_KEYS.gamingVoice, name: "🎮・gaming-voice", category: "community", type: ChannelType.GuildVoice },
  { key: CHANNEL_KEYS.staffChat, name: "🛠️・staff-chat", category: "staff", type: ChannelType.GuildText },
  { key: CHANNEL_KEYS.staffLogs, name: "📋・staff-logs", category: "staff", type: ChannelType.GuildText },
  { key: CHANNEL_KEYS.ticketReview, name: "🧾・ticket-review", category: "staff", type: ChannelType.GuildText },
  { key: CHANNEL_KEYS.staffVoice, name: "🛡️・staff-voice", category: "staff", type: ChannelType.GuildVoice },
] as const;

function isStaff(role: Role) {
  return STAFF_ROLES.includes(roleKeyFromName(role.name) as (typeof STAFF_ROLES)[number]);
}

async function findOrCreateRole(guild: Guild, name: string) {
  const existing = guild.roles.cache.find((role) => role.name === name);
  if (existing) return existing;
  const roleKey = roleKeyFromName(name);
  return guild.roles.create({
    name,
    reason: "Adamohub community setup",
    color:
      roleKey === "Owner"
        ? 0xf59e0b
        : roleKey === "Developer"
          ? 0x8b5cf6
          : roleKey === "Admin"
            ? 0xef4444
            : roleKey === "Moderator"
              ? 0x3b82f6
              : roleKey === "Premium"
                ? 0xfacc15
                : roleKey === "Verified"
                  ? 0x22c55e
                  : 0x64748b,
    hoist: ["Owner", "Developer", "Admin", "Moderator"].includes(roleKey),
  });
}

async function findOrCreateCategory(guild: Guild, name: string) {
  const existing = guild.channels.cache.find(
    (channel): channel is CategoryChannel =>
      channel.type === ChannelType.GuildCategory && channel.name === name,
  );
  if (existing) return existing;
  return guild.channels.create({ name, type: ChannelType.GuildCategory });
}

export async function setupGuild(guild: Guild, ownerId: string): Promise<SetupIds> {
  const roles: Record<string, string> = Object.fromEntries(
    await Promise.all(
      ROLE_NAMES.map(async (key) => [key, (await findOrCreateRole(guild, ROLE_DEFINITIONS[key])).id] as const),
    ),
  );

  const categories: Record<string, string> = Object.fromEntries(
    await Promise.all(
      Object.entries(CATEGORY_NAMES).map(async ([key, name]) => [
        key,
        (await findOrCreateCategory(guild, name)).id,
      ]),
    ),
  );

  const memberRole = guild.roles.cache.get(roles.Member);
  const verifiedRole = guild.roles.cache.get(roles.Verified);
  const everyone = guild.roles.everyone;
  const staffRoleObjects = Object.values(roles)
    .map((roleId) => guild.roles.cache.get(roleId))
    .filter((role): role is Role => Boolean(role && isStaff(role)));
  const ownerRole = guild.roles.cache.get(roles.Owner);

  const channels: Record<string, string> = {};
  for (const definition of channelDefinitions) {
    const categoryId =
      definition.category === "staff"
        ? categories.staff
        : definition.category === "information"
          ? categories.information
          : definition.category === "adamohub"
            ? categories.adamohub
            : categories.community;
    const existing = guild.channels.cache.find(
      (channel) =>
        channel.name === definition.name &&
        channel.parentId === categoryId &&
        channel.type === definition.type,
    );
    const channel =
      existing ??
      (await guild.channels.create({
        name: definition.name,
        type: definition.type,
        parent: categoryId,
        reason: "Adamohub community setup",
      }));
    channels[definition.key] = channel.id;
  }

  for (const definition of channelDefinitions) {
    const channel = guild.channels.cache.get(channels[definition.key]);
    if (!channel || !("permissionOverwrites" in channel)) continue;

    const canPost =
      definition.key === CHANNEL_KEYS.general ||
      definition.key === CHANNEL_KEYS.media ||
      definition.type === ChannelType.GuildForum;
    const isStaffOnly = definition.category === "staff";
    const isTicketReview = definition.key === CHANNEL_KEYS.ticketReview;
    const isVoice = definition.type === ChannelType.GuildVoice;

    await channel.permissionOverwrites.edit(everyone, {
      ViewChannel: !isStaffOnly && !isTicketReview,
      SendMessages: isVoice ? undefined : canPost,
      CreatePublicThreads: canPost,
      CreatePrivateThreads: canPost,
      SendMessagesInThreads: canPost,
      AddReactions: canPost,
      Connect: isVoice ? !isStaffOnly : undefined,
      Speak: isVoice ? !isStaffOnly : undefined,
    });
    if (memberRole) {
      await channel.permissionOverwrites.edit(memberRole, {
        ViewChannel: !isStaffOnly && !isTicketReview,
        SendMessages: isVoice ? undefined : canPost,
        CreatePublicThreads: canPost,
        CreatePrivateThreads: canPost,
        SendMessagesInThreads: canPost,
        AddReactions: canPost,
        Connect: isVoice ? !isStaffOnly : undefined,
        Speak: isVoice ? !isStaffOnly : undefined,
      });
    }
    if (verifiedRole) {
      await channel.permissionOverwrites.edit(verifiedRole, {
        ViewChannel: !isStaffOnly && !isTicketReview,
        SendMessages: isVoice ? undefined : canPost,
        CreatePublicThreads: canPost,
        CreatePrivateThreads: canPost,
        SendMessagesInThreads: canPost,
        AddReactions: canPost,
        Connect: isVoice ? !isStaffOnly : undefined,
        Speak: isVoice ? !isStaffOnly : undefined,
      });
    }
    for (const staffRole of staffRoleObjects) {
      await channel.permissionOverwrites.edit(staffRole, {
        ViewChannel: true,
        SendMessages: isVoice ? undefined : true,
        ManageMessages: true,
        ManageChannels: true,
        ReadMessageHistory: true,
        Connect: isVoice ? true : undefined,
        Speak: isVoice ? true : undefined,
      });
    }
    if (definition.key === CHANNEL_KEYS.ticketReview) {
      for (const staffRole of staffRoleObjects) {
        await channel.permissionOverwrites.edit(staffRole, {
          ViewChannel: false,
          SendMessages: false,
          ManageMessages: false,
          ManageChannels: false,
        });
      }
      if (ownerRole) {
        await channel.permissionOverwrites.edit(ownerRole, {
          ViewChannel: true,
          SendMessages: true,
          ManageMessages: true,
          ManageChannels: true,
          ReadMessageHistory: true,
        });
      }
    }
  }

  await saveSetup(guild.id, ownerId, {
    categories,
    channels,
    roles,
  });
  return { categories, channels, roles };
}

export function getTextChannel(guild: Guild, channelId: string | undefined) {
  const channel = channelId ? guild.channels.cache.get(channelId) : undefined;
  return channel?.type === ChannelType.GuildText ? (channel as TextChannel) : undefined;
}

export function getRole(guild: Guild, roleId: string | undefined) {
  return roleId ? guild.roles.cache.get(roleId) : undefined;
}

export const permissionSets = {
  manager: [
    PermissionFlagsBits.ManageGuild,
    PermissionFlagsBits.ManageRoles,
    PermissionFlagsBits.ManageChannels,
    PermissionFlagsBits.BanMembers,
    PermissionFlagsBits.KickMembers,
    PermissionFlagsBits.ModerateMembers,
  ],
};