# Adamohub Discord Bot

An English-language Discord community bot that provisions Adamohub servers and automates moderation, verification, support tickets, giveaways, notifications, and staff audit logging.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string
- Required secret: `DISCORD_BOT_TOKEN` — Discord Developer Portal bot token

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/api-server/src/discord/bot.ts` — Discord client, slash commands, buttons, menus, event handlers, and scheduled jobs
- `artifacts/api-server/src/discord/setup.ts` — Adamohub roles, categories, channels, and permission overwrites
- `artifacts/api-server/src/discord/transcript.ts` — ticket transcript generation and attachment archiving
- `lib/db/src/schema/discord.ts` — persistent guild, warning, ticket, and giveaway data
- `artifacts/api-server/src/discord/db.ts` — Discord persistence helpers

## Architecture decisions

- The bot runs alongside the existing Express API workflow so one long-running service owns the Discord gateway connection.
- A Discord OAuth connection is not used for bot gateway actions; the bot token is kept in `DISCORD_BOT_TOKEN` and never stored in source.
- Global moderation state is persisted in the shared PostgreSQL database so warnings, tickets, transcripts, and giveaways survive restarts.
- `/setup` is the source of truth for the Adamohub server layout and can be safely rerun to restore missing channels or roles.

## Product

The bot creates the Adamohub server layout with English-facing roles and channels, controls member/staff access, posts welcome and verification panels, opens support or payment tickets, archives transcripts with copied attachments, applies warning escalation, logs staff actions, blocks repeated-message raids, manages notification roles, and runs giveaways.

## User preferences

- Bot-facing text should remain in English because Adamohub is an English server.

## Gotchas

- Discord Developer Portal must have the Server Members Intent and Message Content Intent enabled for join welcomes, anti-raid detection, and full message handling.
- The bot needs Discord permissions to manage channels, roles, messages, moderation actions, reactions, and audit logs; its role must sit above Member/Verified and moderation targets.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
