import { AttachmentBuilder, type Message, type TextChannel } from "discord.js";
import { COLORS } from "./constants";

export async function collectTranscript(channel: TextChannel) {
  const messages: Message[] = [];
  let before: string | undefined;
  for (;;) {
    const batch = await channel.messages.fetch({ limit: 100, before });
    messages.push(...batch.values());
    if (batch.size < 100) break;
    before = batch.last()?.id;
    if (!before) break;
  }
  messages.sort((a, b) => a.createdTimestamp - b.createdTimestamp);
  const lines = messages.map((message) => {
    const attachments = [...message.attachments.values()]
      .map((attachment) => ` [attachment: ${attachment.name ?? "file"}]`)
      .join("");
    return `[${new Date(message.createdTimestamp).toISOString()}] ${message.author.tag}: ${message.content}${attachments}`;
  });
  return { messages, text: lines.join("\n") || "No messages were recorded." };
}

export async function sendTranscript(
  reviewChannel: TextChannel,
  ticketChannel: TextChannel,
  reason: string,
) {
  const { messages, text } = await collectTranscript(ticketChannel);
  const files: AttachmentBuilder[] = [
    new AttachmentBuilder(Buffer.from(text, "utf8"), {
      name: `${ticketChannel.name}-transcript.txt`,
    }),
  ];
  for (const message of messages) {
    for (const attachment of message.attachments.values()) {
      try {
        const response = await fetch(attachment.url);
        if (!response.ok) continue;
        const buffer = Buffer.from(await response.arrayBuffer());
        if (buffer.byteLength <= 8 * 1024 * 1024) {
          files.push(new AttachmentBuilder(buffer, { name: attachment.name ?? "attachment" }));
        }
      } catch {
        // Keep the transcript available even if one external attachment cannot be copied.
      }
    }
  }
  await reviewChannel.send({
    embeds: [
      {
        title: "Ticket transcript archived",
        description: `Ticket **${ticketChannel.name}** was deleted.\nReason: ${reason}`,
        color: COLORS.purple,
        fields: [
          { name: "Messages", value: String(messages.length), inline: true },
          { name: "Attachments copied", value: String(files.length - 1), inline: true },
        ],
        timestamp: new Date().toISOString(),
      },
    ],
    files,
  });
}